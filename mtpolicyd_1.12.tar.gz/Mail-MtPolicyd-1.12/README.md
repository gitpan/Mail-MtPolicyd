mtpolicyd
=========

a modular policy daemon for postfix

Project Website is located at: http://www.mtpolicyd.org/
